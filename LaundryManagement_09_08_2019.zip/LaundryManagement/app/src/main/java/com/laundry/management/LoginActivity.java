package com.laundry.management;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.laundry.management.Activity.MainActivity;
import com.laundry.management.NetUtils.GlobleElement;
import com.laundry.management.NetUtils.MyPreferences;
import com.laundry.management.api.ApiClient;
import com.laundry.management.api.ApiInterface;

import org.json.JSONObject;

import java.util.Locale;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    Button btn_login;
    TextView tv_register;
    String st_type;
    EditText et_mobile, et_pwd;
    Locale locale;
    String lang = "";

    MyPreferences myPreferences;
    Dialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        /* Keyboard Close */
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        myPreferences = new MyPreferences(this);
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        st_type = getIntent().getStringExtra("type");
        btn_login = (Button) findViewById(R.id.btn_login);
        tv_register = (TextView) findViewById(R.id.tv_register);

        et_mobile = (EditText) findViewById(R.id.et_mobile);
        et_pwd = (EditText) findViewById(R.id.et_pwd);


        findViewById(R.id.btn_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (et_mobile.getText().toString().length() < 10) {

                    et_mobile.setError(getResources().getString(R.string.valid_mobile));
                } else if (et_pwd.getText().toString().equals("")) {

                    et_pwd.setError(getResources().getString(R.string.valid_password));
                } else {
                    if (st_type.equals("Store")) {

                        pd = GlobleElement.showprogress(LoginActivity.this);

                        ApiInterface re = ApiClient.getRetrofit().create(ApiInterface.class);
                        Call<ResponseBody> call = re.Store_Login(
                                et_mobile.getText().toString(), et_pwd.getText().toString());
                        call.enqueue(new Callback<ResponseBody>() {
                            @SuppressLint("LongLogTag")
                            @Override
                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//
                                String responseString = null;
                                if (response.isSuccessful()) {
                                    try {
                                        pd.dismiss();
                                        responseString = response.body().string();
                                        // Toast.makeText(LoginActivity.this, responseString, Toast.LENGTH_SHORT).show();
                                        Log.e("Store Login Response :: ", responseString);
                                        JSONObject jsonObject = new JSONObject(responseString);
                                        if (jsonObject.getBoolean("success")) {

                                            myPreferences.setPreferences(MyPreferences.id, jsonObject.getString("id"));
                                            myPreferences.setPreferences(MyPreferences.username, jsonObject.getString("username"));
                                            myPreferences.setPreferences(MyPreferences.shopname, jsonObject.getString("shopname"));
                                            myPreferences.setPreferences(MyPreferences.fullname, jsonObject.getString("fullname"));
                                            myPreferences.setPreferences(MyPreferences.email, jsonObject.getString("email"));
                                            myPreferences.setPreferences(MyPreferences.phone, jsonObject.getString("phone"));
                                            myPreferences.setPreferences(MyPreferences.address_1, jsonObject.getString("address_1"));
                                            myPreferences.setPreferences(MyPreferences.address_2, jsonObject.getString("address_2"));
                                            myPreferences.setPreferences(MyPreferences.city, jsonObject.getString("city"));
                                            myPreferences.setPreferences(MyPreferences.state, jsonObject.getString("state"));
                                            myPreferences.setPreferences(MyPreferences.zip, jsonObject.getString("zip"));
                                            myPreferences.setPreferences(MyPreferences.device_token, jsonObject.getString("device_token"));
                                            myPreferences.setPreferences(MyPreferences.status, jsonObject.getString("status"));
                                            myPreferences.setPreferences(MyPreferences.join_date, jsonObject.getString("join_date"));
                                            Toast.makeText(LoginActivity.this, "" + jsonObject.getString("success_messages"), Toast.LENGTH_LONG);
                                            startActivity(new Intent(LoginActivity.this, MainActivity.class).putExtra("type", "Store"));
                                            finish();


                                        } else {
                                            Toast.makeText(LoginActivity.this, "" + jsonObject.getString("error_messages"), Toast.LENGTH_SHORT).show();
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();

                                    }
                                } else {
                                    Toast.makeText(LoginActivity.this, "Please Try Again Something Went Wrong", Toast.LENGTH_SHORT).show();
                                }

                            }

                            @Override
                            public void onFailure(Call<ResponseBody> call, Throwable t) {
                                Toast.makeText(LoginActivity.this, "fail", Toast.LENGTH_LONG);
                                t.printStackTrace();

                                pd.dismiss();
                            }
                        });
                    } else {
                        pd = GlobleElement.showprogress(LoginActivity.this);

                        ApiInterface re = ApiClient.getRetrofit().create(ApiInterface.class);
                        Call<ResponseBody> call = re.Customer_Login(
                                et_mobile.getText().toString(), et_pwd.getText().toString());
                        call.enqueue(new Callback<ResponseBody>() {
                            @SuppressLint("LongLogTag")
                            @Override
                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//
                                String responseString = null;
                                if (response.isSuccessful()) {
                                    try {
                                        pd.dismiss();
                                        responseString = response.body().string();
                                        // Toast.makeText(LoginActivity.this, responseString, Toast.LENGTH_SHORT).show();
                                        Log.e("Customer Login Response :: ", responseString);
                                        JSONObject jsonObject = new JSONObject(responseString);
                                        if (jsonObject.getBoolean("success")) {

                                            myPreferences.setPreferences(MyPreferences.id, jsonObject.getString("id"));
                                            myPreferences.setPreferences(MyPreferences.store_id, jsonObject.getString("store_id"));
                                            myPreferences.setPreferences(MyPreferences.store_charge_id, jsonObject.getString("store_charge_id"));
                                            myPreferences.setPreferences(MyPreferences.username, jsonObject.getString("username"));
                                            myPreferences.setPreferences(MyPreferences.fullname, jsonObject.getString("fullname"));
                                            myPreferences.setPreferences(MyPreferences.email, jsonObject.getString("email"));
                                            myPreferences.setPreferences(MyPreferences.phone, jsonObject.getString("phone"));
                                            myPreferences.setPreferences(MyPreferences.address_1, jsonObject.getString("address_1"));
                                            myPreferences.setPreferences(MyPreferences.address_2, jsonObject.getString("address_2"));
                                            myPreferences.setPreferences(MyPreferences.city, jsonObject.getString("city"));
                                            myPreferences.setPreferences(MyPreferences.state, jsonObject.getString("state"));
                                            myPreferences.setPreferences(MyPreferences.zip, jsonObject.getString("zip"));
                                            myPreferences.setPreferences(MyPreferences.device_token, jsonObject.getString("device_token"));
                                            myPreferences.setPreferences(MyPreferences.status, jsonObject.getString("status"));
                                            myPreferences.setPreferences(MyPreferences.join_date, jsonObject.getString("join_date"));
                                            Toast.makeText(LoginActivity.this, "" + jsonObject.getString("success_messages"), Toast.LENGTH_LONG);
                                            startActivity(new Intent(LoginActivity.this, MainActivity.class).putExtra("type", "Customer"));
                                            finish();


                                        } else {
                                            Toast.makeText(LoginActivity.this, "" + jsonObject.getString("error_messages"), Toast.LENGTH_SHORT).show();
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();

                                    }
                                } else {
                                    Toast.makeText(LoginActivity.this, "Please Try Again Something Went Wrong", Toast.LENGTH_SHORT).show();
                                }

                            }

                            @Override
                            public void onFailure(Call<ResponseBody> call, Throwable t) {
                                Toast.makeText(LoginActivity.this, "fail", Toast.LENGTH_LONG);
                                t.printStackTrace();

                                pd.dismiss();
                            }
                        });
                    }
                }


            }
        });

        findViewById(R.id.tv_register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
                i.putExtra("type", st_type);
                startActivity(i);
            }
        });

        findViewById(R.id.tv_forgot_pwd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


        /*SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        Configuration config = getBaseContext().getResources().getConfiguration();
        lang = settings.getString("LANG", "");
        if (!"".equals(lang) && !config.locale.getLanguage().equals(lang)) {
            locale = new Locale(lang);
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }*/


        if (st_type.equals("Store")) {

            btn_login.setText(getResources().getString(R.string.store_login));
            tv_register.setText(getResources().getString(R.string.store_register));
        } else {

            btn_login.setText(getResources().getString(R.string.customer_login));
            tv_register.setText(getResources().getString(R.string.customer_register));
        }

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
