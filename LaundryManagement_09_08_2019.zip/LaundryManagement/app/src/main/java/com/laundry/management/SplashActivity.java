package com.laundry.management;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.Bundle;
import android.preference.PreferenceManager;
;import com.laundry.management.NetUtils.GlobleElement;
import com.laundry.management.NetUtils.RuntimePermissionsActivity;

import java.util.Locale;

public class SplashActivity extends RuntimePermissionsActivity {

    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    Locale locale;
    int a = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        preferences = getSharedPreferences("AppLunch", MODE_PRIVATE);

        if (preferences != null) {
            a = preferences.getInt("yes", 0);
        }

       // PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit().putString("LANG", "gj").commit();

        if (GlobleElement.isConnectingToInternet(SplashActivity.this)) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    SplashActivity.super.requestAppPermissions(new
                                    String[]{
                                    Manifest.permission.ACCESS_WIFI_STATE,
                                    Manifest.permission.ACCESS_NETWORK_STATE}, R.string.runtime_permissions_txt
                            , 20);
                }
            }, 3000);
        } else {
            GlobleElement.ErrorDialog(SplashActivity.this,"Internet Connection Not Available ...!!!");

        }
    }



    @Override
    public void onPermissionsGranted(int requestCode) {
        if (requestCode == 20) {
            //getOpCode();


           // startActivity(new Intent(SplashActivity.this, MainActivity.class));


            if (a == 0) {

                a = 1;
                startActivity(new Intent(SplashActivity.this, SelectLanguageActivity.class));
                finish();
                preferences = getSharedPreferences("AppLunch", MODE_PRIVATE);
                editor = preferences.edit();
                editor.putInt("yes", a);
                editor.commit();

            } else {
                //startActivity(new Intent(SplashActivity.this, IntroductionActivity.class));
                startActivity(new Intent(SplashActivity.this, SelectPersonActivity.class));
                finish();
            }
        }
    }

}
