package com.laundry.management.NetUtils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Android-2 on 11-07-2018.
 */

public class DBPerson {
    SQLiteDatabase command;
    connection connection;
    Context context;

    public static int READ_MODE = 0;
    public static int WRITE_MODE = 1;

    public static String db_name = "obotabb2b.db";
    public static String db_backup_foler = "DB New1 Backup";
    public static String db_image_folder = "Shared New1 Images";
    public static String db_csv_folder = "Shared New1 CSV";

    String TABLE_PREPAID = "CREATE TABLE prepaid(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_PREPAID = "drop table prepaid;";


    String TABLE_POSTPAID = "CREATE TABLE postpaid(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_POSTPAID = "drop table postpaid;";


    String TABLE_LANDLINE = "CREATE TABLE landline(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_LANDLINE = "drop table landline;";


    String TABLE_BROADBAND = "CREATE TABLE broadband(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_BROADBAND = "drop table broadband;";



    String TABLE_DATACARD = "CREATE TABLE datacard(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_DATACARD = "drop table datacard;";



    String TABLE_INSURANCE = "CREATE TABLE insurance(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_INSURANCE = "drop table insurance;";


    String TABLE_ELECTRICITY = "CREATE TABLE electricity(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_ELECTRICITY = "drop table electricity;";


    String TABLE_GAS = "CREATE TABLE gas(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_GAS = "drop table gas;";


    String TABLE_WATER = "CREATE TABLE water(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_WATER = "drop table water;";


    String TABLE_EMI = "CREATE TABLE emi(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_EMI = "drop table emi;";


    String TABLE_MPOS = "CREATE TABLE mpos(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_MPOS = "drop table mpos;";


    String TABLE_DMT = "CREATE TABLE dmt(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_DMT = "drop table dmt;";


    String TABLE_DTH = "CREATE TABLE dth(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_DTH = "drop table dth;";

    String TABLE_CARD_TYPE = "CREATE TABLE card_type(id integer primary key autoincrement,"
            + "operator text,opcode text,service_id text,image text)";

    String TABLE_DROP_CARD_TYPE = "drop table card_type;";


    String TABLE_TRAIL = "CREATE TABLE IF NOT EXISTS demo_master("
            + "registerd_date varchar,last_access_date varchar,days integer)";

    SQLiteDatabase db;

    class connection extends SQLiteOpenHelper {
        Context cnx;

        public connection(Context context, String name, SQLiteDatabase.CursorFactory factory,
                          int version) {
            super(context, name, factory, version);
            cnx = context;
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            // create all table
            db.execSQL(TABLE_TRAIL);
            CreateAllTable(db);
            // ==//

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            DropAllTable(db);
            CreateAllTable(db);

        }
    }


    public void onCreate(SQLiteDatabase db) {

        db.execSQL(TABLE_TRAIL);
        CreateAllTable(db);

    }



    void CreateAllTable(SQLiteDatabase db) {

        db.execSQL(TABLE_PREPAID);
        db.execSQL(TABLE_POSTPAID);
        db.execSQL(TABLE_LANDLINE);
        db.execSQL(TABLE_DTH);
        db.execSQL(TABLE_BROADBAND);

        db.execSQL(TABLE_DATACARD);
        db.execSQL(TABLE_INSURANCE);
        db.execSQL(TABLE_ELECTRICITY);

        db.execSQL(TABLE_GAS);
        db.execSQL(TABLE_WATER);
        db.execSQL(TABLE_EMI);
        db.execSQL(TABLE_MPOS);
        db.execSQL(TABLE_DMT);
        db.execSQL(TABLE_CARD_TYPE);

        // ==//

    }

    void DropAllTable(SQLiteDatabase db) {

        db.execSQL(TABLE_DROP_PREPAID);
        db.execSQL(TABLE_DROP_POSTPAID);
        db.execSQL(TABLE_DROP_LANDLINE);
        db.execSQL(TABLE_DROP_DTH);
        db.execSQL(TABLE_DROP_BROADBAND);

        db.execSQL(TABLE_DROP_DATACARD);
        db.execSQL(TABLE_DROP_INSURANCE);
        db.execSQL(TABLE_DROP_ELECTRICITY);

        db.execSQL(TABLE_DROP_GAS);
        db.execSQL(TABLE_DROP_WATER);
        db.execSQL(TABLE_DROP_EMI);
        db.execSQL(TABLE_DROP_MPOS);
        db.execSQL(TABLE_DROP_DMT);
        db.execSQL(TABLE_DROP_CARD_TYPE);
    }

    public void clearAllData() {
        DropAllTable(command);
        CreateAllTable(command);
        Log.e("ClearAllData  :: ","DONE");
    }

    public DBPerson(Context context) {
        this.context = context;
    }

    public void close() {
        command.close();
        if (connection != null) {
            connection.close();
        }
    }

    public void Execute_query(String query) {

        Log.e("query", query);
        if (query.length() > 0)
            command.execSQL(HTMLEntities(query));
    }

    public int ExecuteQuery(String query) {
        Log.e("query", query);

        if (query.length() > 0)
            command.execSQL(HTMLEntities(query));

        return command.rawQuery("select changes();", null).getCount();
    }

    public String HTMLEntities(String str) {
        // return str.replace("&", "&amp;");
        return str;
    }

    public void Open(int MODE) {

        connection = new connection(context, db_name, null, 1);

        if (MODE == 1) {
            command = connection.getWritableDatabase();
        } else {
            command = connection.getReadableDatabase();
        }

        try {
            Log.e("version:", command.getVersion() + "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public long CreateInsurance(String operator, String op_code, String service_id, String img) {

        ContentValues values = new ContentValues();
        values.put("operator", operator);
        values.put("opcode", op_code);
        values.put("service_id", service_id);
        values.put("image", img);

        return command.insert("insurance", null, values);
    }

    public long CreateCardTpye(String operator, String op_code, String service_id, String img) {

        ContentValues values = new ContentValues();
        values.put("operator", operator);
        values.put("opcode", op_code);
        values.put("service_id", service_id);
        values.put("image", img);

        return command.insert("card_type", null, values);
    }

    public Cursor Select_query(String query) {
        Log.w("query", query);
        return command.rawQuery(query, null);
    }

    public Cursor Select_query(String query, String[] selectionArgs) {
        Log.w("query", query);
        return command.rawQuery(query, selectionArgs);
    }
}
