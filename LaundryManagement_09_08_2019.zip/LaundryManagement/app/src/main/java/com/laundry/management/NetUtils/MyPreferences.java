package com.laundry.management.NetUtils;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.GeneralSecurityException;

/**
 * Created by CRAFT BOX on 1/23/2017.
 */

public class MyPreferences {

    Context context;

    public static String PreferenceName="Laundary";
    public static String EncraptionKey="laundry@123456";



    public static String id ="id";
    public static String store_id ="store_id";
    public static String store_charge_id ="store_charge_id";
    public static String username = "username";
    public static String shopname = "shopname";
    public static String fullname = "fullname";
    public static String email = "email";
    public static String phone = "phone";
    public static String address_1="address_1";
    public static String address_2="address_2";
    public static String city = "city";
    public static String state = "state";
    public static String zip = "zip";
    public static String device_token = "device_token";
    public static String status = "status";
    public static String join_date = "join_date";


    public MyPreferences(Context context)
    {
        this.context=context;
    }

    public String getPreferences(String key)
    {
        String value= null;
        try {
            SharedPreferences channel=context.getSharedPreferences(""+ PreferenceName, Context.MODE_PRIVATE);
            value = AESCrypt.decrypt(""+EncraptionKey,channel.getString(""+key,"").toString());
        } catch (Exception e) {
            e.printStackTrace();
            value = "";
            return value;
        }

        return value;
    }
    public String getTutorialPreferance(String Key){
        String value=null;
        try{
            SharedPreferences channel=context.getSharedPreferences(""+PreferenceName, Context.MODE_PRIVATE);
            value=AESCrypt.decrypt(""+EncraptionKey,channel.getString(""+Key,"").toString());
        }
        catch (Exception e){
            e.printStackTrace();
            value="";
            return value;
        }
        return value;
    }
    public void setTutorialPreferance(String key, String Value){
        try {
            SharedPreferences sharedPreferences=context.getSharedPreferences(""+PreferenceName, Context.MODE_PRIVATE);
            SharedPreferences.Editor ed=sharedPreferences.edit();
            ed.putString(""+key,AESCrypt.encrypt(""+EncraptionKey,""+Value));
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        }
    }

    public void setPreferences(String key, String value)
    {
        try {
            SharedPreferences sharedpreferences = context.getSharedPreferences(""+PreferenceName, Context.MODE_PRIVATE);
            SharedPreferences.Editor ed = sharedpreferences.edit();
            ed.putString(""+key,AESCrypt.encrypt(""+EncraptionKey, ""+value));
            ed.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  boolean clearPreferences() {
        try {
            SharedPreferences settings = context.getSharedPreferences("" + PreferenceName, Context.MODE_PRIVATE);
            return settings.edit().clear().commit();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


}
