package com.laundry.management.NetUtils;

import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import java.text.DecimalFormat;

import com.laundry.management.AwesomeDialog.AwesomeProgressDialog;
import com.laundry.management.R;


/**
 * Created by Ahndroid-3 on 12-12-2017.
 */

public class GlobleElement extends Application {
    public static int status;
    public static int bene_status;
    public static String mob;
    public static boolean state = false;
    public static int size = 0;
    public static String ifsc;
    public static String bene;

    public static final String PREFERENCE_WORKING_KEY = "204DAB4DE5BFCDBC1072DA462EEF40A6";
    public static final String PREFERENCE_access_code = "AVSX73EI11BE51XSEB";
    public static final String merchant_id = "148098";
    public static final String Currency = "INR";
    public static final String admin_id = "57";

    public static final String Modetype="B2BAPP";
    public static final String RSA_url = "http://kandoipower.com/ajax/app_ccavenue/GetRSA.php";
    public static String uid = "";
    public static final String Redirect_url = "http://kandoipower.com/ajax/app_ccavenue/ccavResponseHandler.php?user_id=";
    public static final String Cancel_url = "http://kandoipower.com/ajax/app_ccavenue/ccavResponseHandler.php";
    public static final String whichActivity = "whichActivity";

    public static final String FCM_KEY = "AIzaSyAbDK9QJ9foQ_4TvTQxmZzqrsK-tCcU61Q";
    public static String message_pack_name = "OBOTAP";
    public static String OFFLINE_KEY_VALUE = "KPower";
    public static String DMT_2_Token;
    public static String Customer_id;
    public static String Remitter_Mobile;
    public static long perm_txn_limit;
    public static long remaininglimit;
    public static long consumedlimit;
    public static String OFFLINE_MOBILE_DESTINATION = "9229224424";
    public static String logintype="b2b";
    public static Dialog apd;

    public static String amountPlan;
    public static String circlePlan;
    public static String operatorPlan;

    public static String piodataxml="";
    public static double sub_total;
    public static int cart_count;
    public static String getNumber(String text) {
        try {
            String numberOnly = text.replaceAll("[^0-9]", "");
            return numberOnly;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

  /*  public static Dialog showprogress(Context mContext) {

        Dialog progressDialog = new Dialog(mContext);
        progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progressDialog.setContentView(R.layout.list_progressbar);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        progressDialog.setCancelable(false);
        progressDialog.show();
        return progressDialog;


    }
    public static void hideDialog(Dialog pd) {
        pd.dismiss();
    }*/

    public static Dialog showprogress(Context mContext) {

        apd = new AwesomeProgressDialog(mContext).setDialogIconOnly(R.drawable.logo_main).setCancelable(false).show();
        return apd;
    }

    public static Dialog showprogress(Context mContext,String Title) {

        apd= new AwesomeProgressDialog(mContext).setColoredCircle(R.color.colorAccent).setTitle(Title).setMessage("Please Wait...").setCancelable(false).show();
        return apd;
    }

    public static void hideDialog(Dialog pd) {
        pd.dismiss();
    }



    public static boolean isConnectingToInternet(Context context) {
//        ConnectivityManager connectivity = (ConnectivityManager) context
//                .getSystemService(Context.CONNECTIVITY_SERVICE);
//
//        if (connectivity != null) {
//            NetworkInfo info = connectivity.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
//
//            if (info != null) {
//                if (info.isConnected()) {
//                    return true;
//                } else {
//                    NetworkInfo info1 = connectivity.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
//                    if (info1.isConnected()) {
//                        return true;
//                    } else {
//                        return false;
//                    }
//                }
//            }
//        }
//        return false;

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { // connected to the internet
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                // connected to wifi
                return true;
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                // connected to the mobile provider's data plan
                return true;
            }
        } else {
            return false;
            // not connected to the internet
        }
        return false;
    }

    public static void showDialog(Context context) {
        android.support.v7.app.AlertDialog.Builder alertDialog2 = new android.support.v7.app.AlertDialog.Builder(context);
        alertDialog2.setTitle("Internet Connection...");
        alertDialog2.setMessage("Please check your internet connection...");
        alertDialog2.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
                    }
                });
        alertDialog2.show();
    }

    public static double getDiscountPer(String price, String discount) {
        double price1 = Double.parseDouble(price);
        double discount1 = Double.parseDouble(discount);
        double discountper = ((price1 - discount1) / price1) * 100;
        DecimalFormat form = new DecimalFormat("#.##");
        return Double.parseDouble(form.format(discountper));
    }


    public static String DecimalFormat(String value)
    {
        DecimalFormat doubleFormat = new DecimalFormat("#.##");
        doubleFormat.setMinimumFractionDigits(2);
        value=doubleFormat.format(Double.parseDouble(value));
        return value;
    }

    public static String DecimalFormat1(String value)
    {
        DecimalFormat doubleFormat = new DecimalFormat("##,##,##,###.##");
        doubleFormat.setMinimumFractionDigits(2);
        value=doubleFormat.format(Double.parseDouble(value));
        return value;
    }

    public static void showDialogNoProduct(Context context,String title) {
        android.support.v7.app.AlertDialog.Builder alertDialog2 = new android.support.v7.app.AlertDialog.Builder(context);
        alertDialog2.setTitle(title);
        alertDialog2.setMessage("Product not available...");
        alertDialog2.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
                        dialog.dismiss();
                    }
                });
        alertDialog2.show();
    }



    public static int checkamount(double amount, double balance) {
        if (balance < 10) {
            return 0;
        } else if (balance < amount) {
            return 1;
        } else {
            return 2;
        }
    }

    public static void ErrorDialog(Context mContext,String error) {

        /*// dialog = new Dialog(HomeActivity.this,android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        final Dialog dialog = new Dialog(this);
        // dialog = new Dialog(HomeActivity.this, android.R.style.DeviceDefault_Light_ButtonBar); // making dialog full screen

        dialog.setContentView(R.layout.dialog_validation);
        dialog.setCancelable(false);

        TextView tv_dailog_title = (TextView) dialog.findViewById(R.id.tv_title);
        Button btn_ok = (Button) dialog.findViewById(R.id.btn_ok);
        tv_dailog_title.setText(error);

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                dialog.dismiss();
            }
        });


        dialog.show();*/

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        final View customView = layoutInflater.inflate(R.layout.dialog_validation, null);
        AlertDialog.Builder editCustomerPopup = new AlertDialog.Builder(mContext);
        editCustomerPopup.setCancelable(false);
        editCustomerPopup.setView(customView);
        final AlertDialog alertDialog = editCustomerPopup.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();

        TextView txt_header = customView.findViewById(R.id.tv_title);
        txt_header.setText(error);
        Button btn_send = customView.findViewById(R.id.btn_ok);

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();

            }
        });

    }
}
