package com.laundry.management.Utils;

/**
 * Created by HP on 24-Nov-17.
 */

public class Const {

    public static final String PREFERENCE_NAME ="OBOTAP_B2B_PORTAL";
    public static final String PREFERENCE_F_NAME = "fname";
    public static final String PREFERENCE_L_NAME = "lname";
    public static final String PREFERECE_EMAIL ="email";
    public static final String PREFERENCE_IS_USER_LOGGED_IN_B2B = "is_user_logged_in_b2b";
    public static final String PREFERENCE_IS_USER_LOGGED_IN_B2C = "is_user_logged_in_b2c";
    public static final String PREFERENCE_MOBILE_NUMBER = "mobile_number";
    public static final String PREFERENCE_USER_ID ="OBOTAP_ID";
    public static final String PREFERENCE_ADDRESS ="OBOTAP_XYZ";
    public static final String PREFERENCE_UNID ="OBOTAP_UNID";
    public static final String PREFERENCE_CMPNY_NAME ="balance3";
    public static final String PREFERENCE_MPOS_STATUS ="balance2";
    public static final String PREFERENCE_BALANCE ="balance";
    public static final String REFRESH_TOKEN ="REFRESH_TOKEN";
    public static final String PREFERENCE_UNAME ="username";
    public static final String PREFERANCE_PASS="psuis";
    public static final String PREFERENCE_Walllet_Amt ="balance6";
    public static final String PREFERENCE_STATE ="demo_state";
    public static final String PREFERENCE_CITY ="demo_city";
    public static final String PREFERENCE_USER_TYPE="user_type";
    public static final String PREFERENCE_FULL_RIGHTS="full_rights";
    public static final String PREFERENCE_MESSAGE_CHECK="message_check";
    public static final String PREFERENCE_UP_LEVEL_ID = "uplevel_id";

    public static final String PREFERENCE_AEPS_STATUS="aeps_status";
    public static final String PREFERENCE_MPOS1_STATUS="mpos_status";

    public static final String COUNTER_TIME="CT";


}
