package com.laundry.management.Utils;

/**
 * Created by Ahndroid-3 on 21-11-2017.
 */

public class Constans {

    public static final String PREFERENCE_NAME ="OBOTAP_B2B";
    public static final String PREFERENCE_F_NAME = "fname";
    public static final String PREFERENCE_MOBILE = "lname";
    public static final String PREFERECE_EMAIL ="email";
    public static final String PREFERECE_ORDER_ID ="email";
    public static final String PREFERECE_AMOUNT ="email";
    public static final String PREFERECE_MPOS_TRANS = "ID";

    public static final String PREFERENCE_IS_USER_LOGGED_IN = "is_user_logged_in";
    public static final String PREFERENCE_MOBILE_NUMBER = "mobile_number";
}
