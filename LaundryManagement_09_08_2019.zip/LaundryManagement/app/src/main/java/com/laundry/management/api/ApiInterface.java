package com.laundry.management.api;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by Ahndroid-3 on 21-11-2017.
 */

public interface ApiInterface {


    @FormUrlEncoded
    @POST("store/register")
    Call<ResponseBody> Store_Register(
            @Field("id") String id,
            @Field("shopname") String shopname,
            @Field("email") String email,
            @Field("password") String password,
            @Field("fullname") String fullname,
            @Field("phone") String phone,
            @Field("address_1") String address_1,
            @Field("address_2") String address_2,
            @Field("city") String city,
            @Field("state") String state,
            @Field("zip") String zip,
            @Field("device_token") String device_token,
            @Field("device_type") String device_type);

    @FormUrlEncoded
    @POST("customer/register")
    Call<ResponseBody> Customer_Register(
            @Field("id") String id,
            @Field("store_id") String store_id,
            @Field("email") String email,
            @Field("password") String password,
            @Field("fullname") String fullname,
            @Field("phone") String phone,
            @Field("address_1") String address_1,
            @Field("address_2") String address_2,
            @Field("city") String city,
            @Field("state") String state,
            @Field("zip") String zip,
            @Field("device_token") String device_token,
            @Field("device_type") String device_type);

    @FormUrlEncoded
    @POST("store/login")
    Call<ResponseBody> Store_Login(
            @Field("username") String mobile,
            @Field("password") String password);

    @FormUrlEncoded
    @POST("customer/login")
    Call<ResponseBody> Customer_Login(
            @Field("username") String mobile,
            @Field("password") String password);

    @FormUrlEncoded
    @POST("store/updatetoken")
    Call<ResponseBody> Store_Updatetoken(
            @Field("phone") String mobile,
            @Field("device_token") String device_token,
            @Field("id") String id);

    @FormUrlEncoded
    @POST("customer/updatetoken")
    Call<ResponseBody> Customer_Updatetoken(
            @Field("phone") String mobile,
            @Field("device_token") String device_token,
            @Field("id") String id);

    @FormUrlEncoded
    @POST("userlist")
    Call<ResponseBody> User_List(@Field("mobile") String mobilem);


    @FormUrlEncoded
    @POST("update_user_status")
    Call<ResponseBody> Update_User_Status(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("delete_user")
    Call<ResponseBody> Delete_User(@Field("user_id") String user_id);


    @FormUrlEncoded
    @POST("pumpslist")
    Call<ResponseBody> Pump_List(@Field("mobile") String mobilem);


    @FormUrlEncoded
    @POST("update_pump")
    Call<ResponseBody> Update_Pump_Mobile(@Field("pump_id") String pump_id, @Field("mobile") String mobile);

    @FormUrlEncoded
    @POST("breakerslist")
    Call<ResponseBody> Breaker_List(@Field("mobile") String mobilem);


    @FormUrlEncoded
    @POST("update_breaker")
    Call<ResponseBody> Update_Breaker_Mobile(@Field("breaker_id") String breaker_id, @Field("mobile") String mobile);

    @FormUrlEncoded
    @POST("get_pump_mobile")
    Call<ResponseBody> Get_Pump_Mobile(@Field("pump_name") String pump_name);

    @FormUrlEncoded
    @POST("all_pumps_detail")
    Call<ResponseBody> All_Pumps_Detail(@Field("name") String pump_name);

    @FormUrlEncoded
    @POST("get_pump_history")
    Call<ResponseBody> Get_pump_history(@Field("pump_name") String pump_name);


    @FormUrlEncoded
    @POST("get_breaker_mobile")
    Call<ResponseBody> Get_breaker_mobile(@Field("breaker_name") String pump_name);

    @FormUrlEncoded
    @POST("all_breaker_detail")
    Call<ResponseBody> All_breaker_detail(@Field("name") String pump_name);

    @FormUrlEncoded
    @POST("get_breaker_history")
    Call<ResponseBody> get_breaker_history(@Field("breaker_name") String pump_name);
}
