package com.laundry.management;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.laundry.management.Activity.MainActivity;
import com.laundry.management.NetUtils.GlobleElement;
import com.laundry.management.NetUtils.MyPreferences;
import com.laundry.management.api.ApiClient;
import com.laundry.management.api.ApiInterface;

import org.json.JSONObject;

import java.util.Locale;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    TextView tv_title;
    Button btn_store_submit;
    String st_type;
    EditText et_store_person_name, et_store_mobile, et_store_email, et_store_pwd, et_store_name, et_store_address_1, et_store_address_2, et_store_city, et_store_state, et_store_zip;
    String lang = "";
    Locale locale;
    MyPreferences myPreferences;
    Dialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        /* Keyboard Close */
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        st_type = getIntent().getStringExtra("type");

        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText(st_type + " Registration");


        btn_store_submit = (Button) findViewById(R.id.btn_store_submit);

        et_store_person_name = (EditText) findViewById(R.id.et_store_person_name);
        et_store_mobile = (EditText) findViewById(R.id.et_store_mobile);
        et_store_email = (EditText) findViewById(R.id.et_store_email);
        et_store_pwd = (EditText) findViewById(R.id.et_store_pwd);
        et_store_name = (EditText) findViewById(R.id.et_store_name);
        et_store_address_1 = (EditText) findViewById(R.id.et_store_address_1);
        et_store_address_2 = (EditText) findViewById(R.id.et_store_address_2);
        et_store_city = (EditText) findViewById(R.id.et_store_city);
        et_store_state = (EditText) findViewById(R.id.et_store_state);
        et_store_zip = (EditText) findViewById(R.id.et_store_zip);

        findViewById(R.id.btn_store_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //finish();

                if (et_store_person_name.getText().toString().equals("")) {
                    et_store_person_name.setError(getResources().getString(R.string.valid_mobile));
                } else if (et_store_mobile.getText().toString().length() < 10) {
                    et_store_mobile.setError(getResources().getString(R.string.valid_mobile));
                } else if (et_store_email.getText().toString().equals("")) {
                    et_store_email.setError(getResources().getString(R.string.valid_email));
                } else if (et_store_pwd.getText().toString().equals("")) {
                    et_store_pwd.setError(getResources().getString(R.string.valid_password));
                } else if (et_store_name.getText().toString().equals("")) {
                    et_store_name.setError(getResources().getString(R.string.valid_store_name));
                } else if (et_store_address_1.getText().toString().equals("")) {
                    et_store_address_1.setError(getResources().getString(R.string.valid_address_1));
                } else if (et_store_address_2.getText().toString().equals("")) {
                    et_store_address_2.setError(getResources().getString(R.string.valid_address_2));
                } else if (et_store_city.getText().toString().equals("")) {
                    et_store_city.setError(getResources().getString(R.string.valid_city));
                } else if (et_store_state.getText().toString().equals("")) {
                    et_store_state.setError(getResources().getString(R.string.valid_state));
                } else if (et_store_zip.getText().toString().length()<6) {
                    et_store_zip.setError(getResources().getString(R.string.valid_zip));
                }else {

                    pd = GlobleElement.showprogress(RegisterActivity.this);

                    ApiInterface re = ApiClient.getRetrofit().create(ApiInterface.class);
                    Call<ResponseBody> call = re.Store_Register(
                            "1",
                            ""+ et_store_name.getText().toString(),
                            ""+ et_store_pwd.getText().toString(),
                            ""+ et_store_pwd.getText().toString(),
                            ""+ et_store_person_name.getText().toString(),
                            ""+ et_store_mobile.getText().toString(),
                            ""+ et_store_address_1.getText().toString(),
                            ""+ et_store_address_2.getText().toString(),
                            ""+ et_store_city.getText().toString(),
                            ""+ et_store_state.getText().toString(),
                            ""+ et_store_zip.getText().toString(),
                            "123456789",
                            "Android");


                    call.enqueue(new Callback<ResponseBody>() {
                        @SuppressLint("LongLogTag")
                        @Override
                        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//
                            String responseString = null;
                            if (response.isSuccessful()) {
                                try {
                                    pd.dismiss();
                                    responseString = response.body().string();
                                    // Toast.makeText(RegisterActivity.this, responseString, Toast.LENGTH_SHORT).show();
                                    Log.e("Store Register Response :: ", responseString);
                                    JSONObject jsonObject = new JSONObject(responseString);

                                    if (jsonObject.getBoolean("success")) {

                                        myPreferences.setPreferences(MyPreferences.id, jsonObject.getString("id"));
                                        myPreferences.setPreferences(MyPreferences.username, jsonObject.getString("username"));
                                        myPreferences.setPreferences(MyPreferences.shopname, jsonObject.getString("shopname"));
                                        myPreferences.setPreferences(MyPreferences.fullname, jsonObject.getString("fullname"));
                                        myPreferences.setPreferences(MyPreferences.email, jsonObject.getString("email"));
                                        myPreferences.setPreferences(MyPreferences.phone, jsonObject.getString("phone"));
                                        myPreferences.setPreferences(MyPreferences.address_1, jsonObject.getString("address_1"));
                                        myPreferences.setPreferences(MyPreferences.address_2, jsonObject.getString("address_2"));
                                        myPreferences.setPreferences(MyPreferences.city, jsonObject.getString("city"));
                                        myPreferences.setPreferences(MyPreferences.state, jsonObject.getString("state"));
                                        myPreferences.setPreferences(MyPreferences.zip, jsonObject.getString("zip"));
                                        myPreferences.setPreferences(MyPreferences.device_token, jsonObject.getString("device_token"));
                                        myPreferences.setPreferences(MyPreferences.status, jsonObject.getString("status"));
                                        myPreferences.setPreferences(MyPreferences.join_date, jsonObject.getString("join_date"));
                                        Toast.makeText(RegisterActivity.this, "Successfully Registration...!!!" , Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(RegisterActivity.this, MainActivity.class).putExtra("type", "Store"));
                                        finish();


                                    } else {
                                        Toast.makeText(RegisterActivity.this, "" + jsonObject.getString("error_messages"), Toast.LENGTH_SHORT).show();
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();

                                }
                            } else {
                                Toast.makeText(RegisterActivity.this, "Please Try Again Something Went Wrong", Toast.LENGTH_SHORT).show();
                            }

                        }

                        @Override
                        public void onFailure(Call<ResponseBody> call, Throwable t) {
                            Toast.makeText(RegisterActivity.this, "fail", Toast.LENGTH_LONG);
                            t.printStackTrace();

                            pd.dismiss();
                        }
                    });
                }

            }
        });

        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        Configuration config = getBaseContext().getResources().getConfiguration();
        lang = settings.getString("LANG", "");
        if (!"".equals(lang) && !config.locale.getLanguage().equals(lang)) {
            locale = new Locale(lang);
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }


        if (st_type.equals("Store")) {

            tv_title.setText(getResources().getString(R.string.store_register));
        } else {

            tv_title.setText(getResources().getString(R.string.customer_register));
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        finish();
    }
}
